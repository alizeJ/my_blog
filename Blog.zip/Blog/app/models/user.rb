class User < ApplicationRecord
  include ActiveModel::Validations
  mount_uploader :avatar, AvatarUploader
  has_secure_password
  validates :password,:password_confirmation, presence: true,
            length: { minimum: 5 }
  validates :username, uniqueness: true, presence: true, length: {minimum: 3}, on: :create
  # validates_with :UsernameValidateor
  has_many :posts
  has_many :categories
  has_many :comments

end