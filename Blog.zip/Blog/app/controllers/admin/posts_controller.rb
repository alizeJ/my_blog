class Admin::PostsController < Admin::BaseController
  layout 'admin_index'
  def index
    @posts = Post.where(user_id: current_user.id)
  end

  def new

  end

  def create

  end

  def destroy

  end

  def update

  end




end