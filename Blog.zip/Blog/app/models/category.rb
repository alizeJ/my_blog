class Category < ApplicationRecord

end