class CommentsController < ApplicationController

  def create
    pp params
    @post = Post.where(id: params[:post_id]).first
    @comment = Comment.new(user_id: current_user.id, post_id: params[:post_id], content: params[:comment][:content])

    respond_to do |format|
      if @comment.save
        format.js
      end
    end
  end

  private
    def comment_params
      params.require(:comment).permit(:content)
    end
end
