class CreateUser < ActiveRecord::Migration[5.2]
  def change
    create_table :users do |t|
      t.string :username, null: false, limit: 64
      t.string :password_digest, null: false
      t.string :avatar, default: '../images/default.jpg'
      t.timestamps
    end

    add_index :users, :username

    create_table :posts do |t|
      t.string :title, null: false, limit: 64
      t.text :content, limit: 8
      t.integer :user_id
      t.datetime :publish_at
      t.timestamps
    end

    add_index :Article, :title
    add_index :Article, :user_id

    create_table :categories do |t|
      t.integer :user_id
      t.string :title, null: false
    end

    add_index :categories, :user_id

    create_table :comments do |t|
      t.integer :user_id
      t.integer :post_id
      t.string :content
      t.timestamps
    end

    create_join_table :categories, :posts

  end
end
