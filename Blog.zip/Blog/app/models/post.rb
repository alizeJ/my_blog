class Post < ApplicationRecord
  validates :title, presence: true

  has_many :categories
  has_many :comments
  belongs_to :user
end