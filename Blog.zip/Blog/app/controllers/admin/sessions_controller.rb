class Admin::SessionsController < Admin::BaseController
  skip_before_action :authenticate, only: [:new, :create]

  def new
  end

  def create
    user = User.where(username: params[:session][:username]).first
    if user && user.authenticate(params[:session][:password])
      sign_in user
      redirect_to admin_root_path
    else
      flash[:danger] = 'Invalid email/password combination'
      render 'new'
    end
  end

  def destroy
    sign_out
    redirect_to root_path
  end
end
