class PostsController < ApplicationController


  def index
    @posts = Post.all
  end

  def show
    @post = Post.where(id: params[:id]).first
    @comment = Comment.new

  end
end
